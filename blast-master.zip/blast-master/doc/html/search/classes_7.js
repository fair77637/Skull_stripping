var searchData=
[
  ['simple3dbatchgenerator',['Simple3DBatchGenerator',['../classblast_1_1cnn_1_1BatchGenerator_1_1Simple3DBatchGenerator.html',1,'blast::cnn::BatchGenerator']]],
  ['spatialpyramidpooling3ddnnlayer',['SpatialPyramidPooling3DDNNLayer',['../classblast_1_1cnn_1_1SpecialLayers_1_1SpatialPyramidPooling3DDNNLayer.html',1,'blast::cnn::SpecialLayers']]]
];
