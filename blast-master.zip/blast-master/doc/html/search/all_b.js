var searchData=
[
  ['normalize',['normalize',['../classblast_1_1tools_1_1PreProcessor_1_1PreProcessor.html#a6bc51a8f3fd1d48b422a0471f4f23505',1,'blast::tools::PreProcessor::PreProcessor']]],
  ['normalizect',['normalizeCT',['../classblast_1_1tools_1_1PreProcessor_1_1PreProcessor.html#a0e657b58da769615842cf5058c453030',1,'blast::tools::PreProcessor::PreProcessor']]],
  ['normalizegivenmeanstd',['normalizeGivenMeanStd',['../classblast_1_1tools_1_1PreProcessor_1_1PreProcessor.html#a710219326225d744ce2a9cb8f9ed3609',1,'blast::tools::PreProcessor::PreProcessor']]],
  ['nyulnormalizer',['NyulNormalizer',['../classblast_1_1tools_1_1NyulNormalizer_1_1NyulNormalizer.html',1,'blast::tools::NyulNormalizer']]]
];
