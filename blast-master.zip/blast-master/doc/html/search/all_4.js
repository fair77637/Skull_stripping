var searchData=
[
  ['dataaugmenter',['DataAugmenter',['../classblast_1_1cnn_1_1DataAugmenter_1_1DataAugmenter.html',1,'blast::cnn::DataAugmenter']]],
  ['deletelasttransformationfiles',['deleteLastTransformationFiles',['../classblast_1_1tools_1_1Dropreg_1_1Dropreg.html#a907b44f4f646cb8b1295cba9e52b9995',1,'blast::tools::Dropreg::Dropreg']]],
  ['densecrf3d',['DenseCRF3D',['../classblast_1_1tools_1_1DenseCRF3D_1_1DenseCRF3D.html',1,'blast::tools::DenseCRF3D']]],
  ['dropreg',['Dropreg',['../classblast_1_1tools_1_1Dropreg_1_1Dropreg.html',1,'blast::tools::Dropreg']]],
  ['dummybatchgenerator',['DummyBatchGenerator',['../classblast_1_1cnn_1_1BatchGenerator_1_1DummyBatchGenerator.html',1,'blast::cnn::BatchGenerator']]]
];
