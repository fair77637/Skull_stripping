var searchData=
[
  ['wholevolumebatchgenerator',['WholeVolumeBatchGenerator',['../classblast_1_1cnn_1_1BatchGenerator_1_1WholeVolumeBatchGenerator.html',1,'blast::cnn::BatchGenerator']]]
];
