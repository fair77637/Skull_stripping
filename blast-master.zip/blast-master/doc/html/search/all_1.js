var searchData=
[
  ['augmentrandomffd',['augmentRandomFFD',['../classblast_1_1cnn_1_1DataAugmenter_1_1DataAugmenter.html#a2a855445368f6c855e30eccbf598101b',1,'blast::cnn::DataAugmenter::DataAugmenter']]]
];
