var searchData=
[
  ['checkdeform',['checkDeform',['../classblast_1_1cnn_1_1BatchGenerator_1_1Simple3DBatchGenerator.html#a6fa65452723f4abdb71b9ea6fd7300dc',1,'blast::cnn::BatchGenerator::Simple3DBatchGenerator']]],
  ['createmodel',['createModel',['../classblast_1_1cnn_1_1Blast_1_1Blast.html#abc43d65eb88cc03fd6b14d4932daae45',1,'blast::cnn::Blast::Blast']]],
  ['crop',['crop',['../classblast_1_1cnn_1_1Blast_1_1Blast.html#a63b63aa1c9472ef0c3319973035afdce',1,'blast::cnn::Blast::Blast']]],
  ['croproiandmakeitmultipleof',['cropRoiAndMakeItMultipleOf',['../classblast_1_1cnn_1_1Blast_1_1Blast.html#a3ac3f1f9ee7f63b46d35b9516fdcef96',1,'blast.cnn.Blast.Blast.cropRoiAndMakeItMultipleOf()'],['../classblast_1_1tools_1_1PreProcessor_1_1PreProcessor.html#a4d60652f3cf25c2e7ba42607f0c954a8',1,'blast.tools.PreProcessor.PreProcessor.cropRoiAndMakeItMultipleOf()']]]
];
