var searchData=
[
  ['_5f_5finit_5f_5f',['__init__',['../classblast_1_1cnn_1_1BatchGenerator_1_1BatchGenerator.html#ace6ad37749eff5d946977c85aa815cd2',1,'blast.cnn.BatchGenerator.BatchGenerator.__init__()'],['../classblast_1_1cnn_1_1BatchGenerator_1_1Simple3DBatchGenerator.html#a4014b076fda44a9ca059803a75709bcf',1,'blast.cnn.BatchGenerator.Simple3DBatchGenerator.__init__()']]]
];
